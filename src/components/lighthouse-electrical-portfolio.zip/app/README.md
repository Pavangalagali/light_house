# Lighthouse & Electrical Shop Portfolio

A showcase portfolio for a lighthouse and electrical shop: categorized lighting
solutions, major electrical appliances, discounted prices, store locations, and
an admin portal for managing the catalog.

## Run Locally

**Prerequisites:** Node.js

1. Install dependencies:
   ```
   npm install
   ```
2. Start the dev server:
   ```
   npm run dev
   ```
3. Build for production:
   ```
   npm run build
   ```

## Tech Stack

- React 19 + TypeScript
- Vite
- Tailwind CSS
- lucide-react (icons)
- motion (animations)
